import TrelloBoard from "../components/TaskBoard ";
import Footer from "../components/Footer";
import React from "react";

const Home = () => {
  return (
    <div>
      <TrelloBoard />
      <Footer />
    </div>
  );
};
export default Home;
