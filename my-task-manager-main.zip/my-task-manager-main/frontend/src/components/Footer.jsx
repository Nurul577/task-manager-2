const Footer = () => {
  return (
    <div className="flex justify-center content-center gap-4">
      <h1>abcd</h1>
      <a
        href="#"
        target="_blank"
        rel="noopener noreferrer"
      >
        GitHub |
      </a>
      <a
        href="#"
        target="_blank"
        rel="noopener noreferrer"
      >
        LinkedIn |
      </a>
      <h1>
        Nurul
      </h1>
    </div>
  );
};
export default Footer;
